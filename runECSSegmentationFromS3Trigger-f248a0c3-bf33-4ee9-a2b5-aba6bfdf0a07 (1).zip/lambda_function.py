import json
import boto3

def lambda_handler(event, context):
    ecs_client = boto3.client('ecs')
    
    try:
        # Loop over each record in the SQS event
        for record in event['Records']:
            # The SQS message body contains the S3 event as a JSON string
            s3_event = json.loads(record['body'])
            s3_record = s3_event['Records'][0]
            s3_key = s3_record['s3']['object']['key']
            print(f"[DEBUG] Received S3 key: {s3_key}")
            
            # If the key ends with a slash, it's a folder—not an actual file—so skip it
            if s3_key.endswith("/"):
                print(f"[INFO] Skipping folder key: {s3_key}")
                continue

            # Extract the user folder from the key (assumes key format "userId/filename.tif")
            userId = s3_key.split('/')[0]
            print(f"[DEBUG] Extracted userId: {userId} from S3 key: {s3_key}")

            # Launch an ECS Fargate task, passing both USER_UID and INPUT_KEY as environment variables
            response = ecs_client.run_task(
                cluster='Neuron-Segmentation',  # Replace with your ECS cluster name
                launchType='FARGATE',
                taskDefinition='run-segmentation:3',  # Use the correct revision for your task definition
                count=1,
                platformVersion='LATEST',
                networkConfiguration={
                    'awsvpcConfiguration': {
                        'subnets': [
                            'subnet-0b8070df08a0d2a7d',
                            'subnet-0a992a5ee7da2403c',
                            'subnet-09fa7a6ab4a211dea',
                            'subnet-06b2887e45508b747',
                            'subnet-07bf47f52aa849503',
                            'subnet-013a571a02ff486b0'
                        ],
                        'assignPublicIp': 'ENABLED'
                    }
                },
                overrides={
                    'containerOverrides': [
                        {
                            'name': 'segmentation',  # Must match the container name in your ECS task definition
                            'environment': [
                                {'name': 'USER_UID', 'value': userId},
                                {'name': 'INPUT_KEY', 'value': s3_key}
                            ]
                        }
                    ]
                }
            )
            print("[DEBUG] ECS Task Response:", response)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Task(s) started successfully'
            })
        }
    
    except Exception as e:
        print("[ERROR] Exception starting ECS task:", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Failed to start ECS task',
                'error': str(e)
            })
        }
